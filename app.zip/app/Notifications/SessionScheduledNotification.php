<?php

namespace App\Notifications;

use App\Channels\OpenWAChannel;
use App\Contracts\WhatsAppNotificationInterface;
use App\Models\TreatmentSession;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Carbon\Carbon;

class SessionScheduledNotification extends Notification implements ShouldQueue, WhatsAppNotificationInterface
{
    use Queueable;

    protected $session;

    /**
     * Create a new notification instance.
     */
    public function __construct(TreatmentSession $session)
    {
        $this->session = $session->load(['patient', 'doctor', 'item.serviceDetail', 'branch.primaryAddress.commune']);
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via($notifiable): array
    {
        $channels = ['mail'];

        // Determinar preferencias
        $wantsWhatsapp = $notifiable->prefers_whatsapp ?? true;

        // Preferencia WhatsApp (OpenWA)
        if ($wantsWhatsapp && $notifiable->phone) {
            $channels[] = OpenWAChannel::class;
        }

        return $channels;
    }

    /**
     * Get the WhatsApp representation of the notification.
     */
    public function toTwilioWhatsAppChannel($notifiable): array
    {
        $date = Carbon::parse($this->session->date)->format('d/m/Y');
        $time = Carbon::parse($this->session->time)->format('H:i');
        
        $isPatient = $notifiable instanceof \App\Models\Patient;
        $patientName = $this->session->patient ? $this->session->patient->name : 'el paciente';

        $instrucciones = $this->session->item?->serviceDetail?->patient_instructions;
        $instruccionesStr = $instrucciones ? "\n\n💡 *Instrucciones:* {$instrucciones}" : "";

        if ($isPatient) {
            $msg = "Hola {$notifiable->name}, te confirmamos *tu sesión* para el día *{$date}* a las *{$time}*.\n\n📍 *Lugar:* " . ($this->session->branch->name ?? 'Clínica') . $instruccionesStr . "\n\nTe esperamos.";
        } else {
            $msg = "Hola {$notifiable->name}, te confirmamos la sesión de *{$patientName}* para el día *{$date}* a las *{$time}*.\n\n📍 *Lugar:* " . ($this->session->branch->name ?? 'Clínica') . $instruccionesStr . "\n\nLos esperamos.";
        }

        return ['body' => "✅ *Hora Agendada*\n\n" . $msg];
    }

    /**
     * Get the mail representation of the notification.
     */
    public function toMail(object $notifiable): MailMessage
    {
        $date = Carbon::parse($this->session->date)->format('d/m/Y');
        $time = Carbon::parse($this->session->time)->format('H:i');
        $doctorName = $this->session->doctor ? $this->session->doctor->full_name : 'un profesional de nuestro equipo';
        
        $isPatient = $notifiable instanceof \App\Models\Patient;
        $patientName = $this->session->patient ? $this->session->patient->name : 'el paciente';

        $mail = (new MailMessage)
            ->subject('✅ Hora Agendada: ' . $date . ' a las ' . $time)
            ->greeting('Hola ' . $notifiable->name . ',');

        if ($isPatient) {
            $mail->line('Tu sesión ha sido agendada exitosamente.');
        } else {
            $mail->line("La sesión de {$patientName} ha sido agendada exitosamente.");
        }

        $branchName = $this->session->branch ? $this->session->branch->name : 'Nuestra Clínica';
        $fullAddress = '';
        if ($this->session->branch && $this->session->branch->primaryAddress) {
            $addr = $this->session->branch->primaryAddress;
            $fullAddress = " ({$addr->street} {$addr->number}, " . ($addr->commune->name ?? '') . ")";
        }

        $mail->line('📅 Fecha: ' . $date)
            ->line('⏰ Hora: ' . $time)
            ->line('👨‍⚕️ Profesional: ' . $doctorName)
            ->line('📍 Lugar: ' . $branchName . $fullAddress);

        if ($instrucciones) {
            $mail->line('💡 **Instrucciones importantes:** ' . $instrucciones);
        }

        return $mail
            ->action('Ver Atenciones', route('patient.login'))
            ->line('¡Nos vemos pronto!');
    }
}
