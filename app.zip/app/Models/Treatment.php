<?php

namespace App\Models;

use App\Traits\Multitenantable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphToMany;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

use App\Enums\TreatmentStatusEnum;
use App\Enums\TreatmentPhaseEnum;

class Treatment extends Model
{
    use HasFactory, SoftDeletes, Multitenantable;

    protected $fillable = [
        'company_id',
        'branch_id',
        'patient_id',
        'doctor_id',
        'plan_id',
        'item_id',

        // Origen
        'referral_doctor_name',
        'referral_diagnosis',
        'referral_date',

        // Diagnóstico Kine
        'diagnostic_code',
        'additional_diagnoses',
        'body_part',
        'laterality',
        'description',

        // Estado y Config
        'status',
        'current_phase',
        'start_date',
        'end_date',
        'next_appointment',
        
        // Línea Base (Inputs)
        'initial_pain_level',
        'initial_pain_map',
        'objectives',

        // Resultados (Outputs)
        'outcome',
        'discharge_reason',
        'pain_reduction',
        'mobility_improvement',
        'strength_gain',

        // Control
        'total_sessions',
        'completed_sessions',
        'frequency',
        'frequency_time',
        'is_indefinite',
    ];

    protected $casts = [
        'start_date' => 'date',
        'end_date' => 'date',
        'referral_date' => 'date',
        'next_appointment' => 'datetime',
        'is_indefinite' => 'boolean',
        'status' => TreatmentStatusEnum::class,
        'current_phase' => TreatmentPhaseEnum::class,
        
        // JSONs Vitales
        'additional_diagnoses' => 'array',
        'initial_pain_map' => 'array',
        'objectives' => 'array',
    ];

    // --- Relaciones ---

    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }
    
    public function diagnostic(): BelongsTo
    {
        return $this->belongsTo(Diagnostic::class, 'diagnostic_code', 'code');
    }

    public function item(): BelongsTo
    {
        return $this->belongsTo(Item::class);
    }

    public function doctor(): BelongsTo
    {
        return $this->belongsTo(Doctor::class);
    }

    public function sessions(): HasMany
    {
        return $this->hasMany(TreatmentSession::class);
    }

    public function lastSession(): HasOne
    {
        return $this->hasOne(TreatmentSession::class)->latestOfMany();
    }

    public function attachments(): HasMany
    {
        return $this->hasMany(Attachment::class);
    }

    /**
     * Scopes
     */
    public function scopeEvaluation($query)
    {
        return $query->where('status', TreatmentStatusEnum::EVALUATION);
    }

    public function scopeActive($query)
    {
        return $query->where('status', TreatmentStatusEnum::IN_PROGRESS);
    }

    public function scopeCancelled($query)
    {
        return $query->where('status', TreatmentStatusEnum::CANCELLED);
    }

    public function scopePaused($query)
    {
        return $query->where('status', TreatmentStatusEnum::PAUSED);
    }

    public function scopeCompleted($query)
    {
        return $query->where('status', TreatmentStatusEnum::COMPLETED);
    }

    public function scopeForPatient($query, $patientId)
    {
        return $query->where('patient_id', $patientId);
    }

    /**
     * Accessors & Mutators
     */
    public function getProgressPercentageAttribute(): float
    {
        if ($this->total_sessions && $this->total_sessions > 0) {
            return round(($this->completed_sessions / $this->total_sessions) * 100, 1);
        }
        return 0;
    }

    public function getNextSessionNumberAttribute(): int
    {
        return ($this->completed_sessions ?? 0) + 1;
    }

    /**
     * Métodos de utilidad
     */
    public function isCompleted(): bool
    {
        return $this->status === TreatmentStatusEnum::COMPLETED;
    }

    public function isActive(): bool
    {
        return $this->status === TreatmentStatusEnum::IN_PROGRESS;
    }

    public function incrementCompletedSessions(): void
    {
        $this->increment('completed_sessions');

        // Si completó todas las sesiones y NO es indefinido, marcar como completado
        if (!$this->is_indefinite && $this->total_sessions && $this->completed_sessions >= $this->total_sessions) {
            $this->update(['status' => TreatmentStatusEnum::COMPLETED]);
        }
    }

    public function calculateKPIs(): array
    {
        $sessions = $this->sessions()->completed()->get();

        if ($sessions->isEmpty()) {
            return [
                'pain_reduction' => 0,
                'mobility_improvement' => 0,
                'strength_gain' => 0,
            ];
        }

        $totalPainReduction = 0;
        $totalMobilityImprovement = 0;
        $totalStrengthGain = 0;

        foreach ($sessions as $session) {
            if ($session->pain_before && $session->pain_after) {
                $totalPainReduction += (($session->pain_before - $session->pain_after) / $session->pain_before) * 100;
            }
            // ROM y otros KPIs se calcularían aquí según el tipo de tratamiento
        }

        $count = $sessions->count();

        return [
            'pain_reduction' => round($totalPainReduction / $count, 1),
            'mobility_improvement' => round($totalMobilityImprovement / $count, 1),
            'strength_gain' => round($totalStrengthGain / $count, 1),
        ];
    }

    public const BODY_PARTS = [
        'head_neck' => 'Cabeza y Cuello',
        'shoulder' => 'Hombro',
        'arm_elbow' => 'Brazo y Codo',
        'wrist_hand' => 'Muñeca y Mano',
        'thoracic_spine' => 'Columna Torácica',
        'lumbar_spine' => 'Columna Lumbar',
        'hip' => 'Cadera / Pelvis',
        'thigh' => 'Muslo',
        'knee' => 'Rodilla',
        'leg_ankle' => 'Pierna y Tobillo',
        'foot' => 'Pie',
        'abdomen' => 'Abdomen',
        'neurological' => 'Neurológico (Global)',
        'respiratory' => 'Respiratorio (Global)',
    ];

    // Un helper para obtener la lista en el frontend
    public static function getBodyPartsList() {
        return self::BODY_PARTS;
    }
}
