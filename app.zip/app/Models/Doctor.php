<?php

namespace App\Models;

use App\Models\Concerns\HasAddresses;
use App\Traits\Multitenantable;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\DB;

class Doctor extends Model
{
    use HasFactory, HasAddresses, Multitenantable;

    protected $fillable = [
        'company_id',
        'user_id',
        'name',
        'last_name',
        'rut',
        'email',
        'phone',
        'speciality',
        'is_active',
        'birth_date',
        'gender',
        'signature_path',
    ];

    protected $casts = [
        'birth_date' => 'date:Y-m-d',
        'is_active' => 'boolean'
    ];

    /* RELACIONES */
    // Indica la relación M:N con Company
    public function companies(): BelongsToMany
    {
        // Usa la tabla pivote 'company_doctor'. 
        // withPivot() te permite acceder a campos de la tabla pivote (como la tarifa).
        return $this->belongsToMany(Company::class, 'company_doctor')
            ->withPivot('tarifa_acordada', 'porcentaje_comision', 'estado_convenio')
            ->withTimestamps();
    }

    public function branches()
    {
        return $this->belongsToMany(Branch::class, 'branch_doctor')
            ->withPivot(['status', 'mobile_app_access', 'can_create_sessions', 'can_view_sessions', 'can_manage_schedule', 'status_reason', 'status_changed_at'])
            ->withTimestamps();
    }

    public function patientAssignments(): HasMany
    {
        return $this->hasMany(DoctorPatientAssignment::class);
    }

    public function patients()
    {
        return $this->belongsToMany(Patient::class, 'doctor_patient_assignments')
            ->withPivot([
                'company_id',
                'branch_id',
                'role',
                'is_primary',
                'is_own_patient',
                'started_at',
                'ended_at'
            ])
            ->withTimestamps();
    }

    public function sessions(): HasMany
    {
        return $this->hasMany(TreatmentSession::class);
    }

    public function appointments(): HasMany
    {
        return $this->hasMany(Appointment::class);
    }

    public function treatmentSessions(): HasMany
    {
        return $this->sessions();
    }

    public function payrolls(): HasMany
    {
        return $this->hasMany(Payroll::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function address(): MorphOne
    {
        return $this->morphOne(Address::class, 'addressable');
    }


    public function commissionRates(): HasMany
    {
        return $this->hasMany(DoctorCommissionRate::class);
    }

    public function activeCommissionRates(): HasMany
    {
        return $this->hasMany(DoctorCommissionRate::class)
            ->active()
            ->validAt(now());
    }

    /*  ----------------- CÁLCULOS -------------------- */
    public function getCommissionForSession($itemId, $basePrice)
    {
        $rate = DoctorCommissionRate::getApplicableCommission(
            $this->id,
            $itemId
        );

        if (!$rate) {
            return 0; // Sin comisión configurada
        }

        return $rate->calculateCommission($basePrice);
    }

    /* -------------- Attributes GETTERS ---------------- */

    /* Sesiones asistidas del mes */
    public function sessionsMonth(): Attribute
    {
        return Attribute::make(
            get: fn() => $this->treatmentSessions()
                ->where('company_id', $this->company_id)
                ->where('status', \App\Enums\AppointmentStatusEnum::COMPLETED)
                ->whereMonth('date', now()->month)
                ->whereYear('date', now()->year)
                ->count()
        );
    }

    /* Ganancias validadas del mes */
    public function revenueMonth(): Attribute
    {
        return Attribute::make(
            get: fn() => $this->treatmentSessions()
                ->where('company_id', $this->company_id)
                ->where('status', \App\Enums\AppointmentStatusEnum::COMPLETED)
                ->whereMonth('date', now()->month)
                ->whereYear('date', now()->year)
                ->sum('doctor_amount_clp')
        );
    }

    /* Conteo de sesiones pendientes (Programadas para el futuro) */
    public function pendingSessionsCount(): Attribute
    {
        return Attribute::make(
            get: fn() => $this->treatmentSessions()
                ->where('status', \App\Enums\AppointmentStatusEnum::SCHEDULED)
                ->where('date', '>=', now()->toDateString())
                ->count()
        );
    }

    /* Pacientes asignados */
    public function assignedPatients(): Attribute
    {
        return Attribute::make(
            get: fn() => $this->patients ? $this->patients : null,
        );
    }

    /* Edad */
    public function age(): Attribute
    {
        return Attribute::make(
            get: fn() => $this->birth_date ? $this->birth_date->diffInYears(Carbon::now()) : null,
        );
    }

    /* Dirección completa */
    protected function fullAddress(): Attribute
    {
        return Attribute::make(
            get: function() {
                if (!$this->address) return '';
                
                return trim(
                    ($this->address->street ?? '') . ' ' . 
                    ($this->address->number ?? '') . ' ' . 
                    ($this->address->commune?->name ?? '') . ' ' . 
                    ($this->address->region?->name ?? '')
                );
            }
        );
    }

    /* Nombre completo */
    public function fullName(): Attribute
    {
        return Attribute::make(
            get: fn() => trim(
                ($this->name ?? '') . ' ' . ($this->last_name ?? '')
            ),
        );
    }

    public function signatureUrl(): Attribute
    {
        return Attribute::make(
            get: fn() => $this->signature_path ? route('doctors.signature.stream', $this->id) : null,
        );
    }

    public function getBranchAttribute()
    {
        $activeBranchId = session('active_branch_id');

        if (!$activeBranchId) return null;

        // Buscamos la sucursal específica con sus datos de la tabla pivote
        $branch = $this->branches()
            ->where('branches.id', $activeBranchId)
            ->first();

        if (!$branch || !$branch->pivot) return null;

        return [
            'id' => $branch->pivot->id ?? null,
            'status' => $branch->pivot->status,
            'mobile_app_access' => (bool) $branch->pivot->mobile_app_access,
            'can_create_sessions' => (bool) ($branch->pivot->can_create_sessions ?? true),
            'can_view_sessions' => (bool) ($branch->pivot->can_view_sessions ?? true),
            'can_manage_schedule' => (bool) ($branch->pivot->can_manage_schedule ?? true),
            'status_reason' => $branch->pivot->status_reason,
            'status_changed_at' => $branch->pivot->status_changed_at,
        ];
    }


    protected $appends = [
        'age', /* Edad */
        'full_address',/* Dirección completa */
        'assigned_patients',/* Pacientes Asignados */
        'sessions_month',/* Sesiones del mes */
        'revenue_month',/* Ganancias del mes */
        'pending_sessions_count', /* Pendientes */
        'full_name',/* Nombre completo */
        'signature_url',
        'branch'
    ];
}
