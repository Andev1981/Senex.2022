<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class HealthInsurer extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name',
        'rut',
        'phone',
        'email',
        'address',
        'website',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function plans()
    {
        return $this->morphMany(Plan::class, 'institution');
    }
}