<?php

namespace App\Http\Middleware;

use App\Models\Branch;
use App\Models\Company;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Inertia\Middleware;

use App\Enums\AppointmentStatusEnum;
use App\Enums\FinanceStatusEnum;
use App\Enums\DteStatusEnum;
use App\Enums\GenderEnum;
use App\Enums\MaritalStatusEnum;
use App\Enums\SeverityEnum;
use App\Enums\SessionCategoryEnum;
use App\Enums\TreatmentStatusEnum;
use App\Enums\TreatmentPhaseEnum;
use App\Enums\PaymentMethodEnum;
use App\Enums\CommissionTypeEnum;
use App\Enums\CommonStatusEnum;

class HandleInertiaRequests extends Middleware
{
    // ...

    public function share(Request $request): array
    {
        $user = $request->user();

        // --- 1. AUTO-DESCUBRIMIENTO DE CONTEXTO ---
        // Si el usuario entró directo y no tiene sesión de contexto, la inicializamos
        if ($user && (!session('current_company_id') || !session('active_branch_id'))) {
            $company = $user->company ?: \App\Models\Company::first();

            if ($company) {
                if (!session('current_company_id')) {
                    session(['current_company_id' => $company->id]);
                }

                if (!session('active_branch_id')) {
                    $branch = $company->branches()->first();
                    if ($branch) {
                        session(['active_branch_id' => $branch->id]);
                    }
                }
                // Guardar cambios en sesión física
                $request->session()->save();
            }
        }

        $context = $this->getAuthContext($request);

        return [
            ...parent::share($request),
            'auth' => $context['auth'],

            // ENUMS COMPARTIDOS (Centralizados para todo el Frontend)
            'enums' => [
                'appointment_status' => AppointmentStatusEnum::options(),
                'finance_status'     => FinanceStatusEnum::options(),
                'dte_status'         => DteStatusEnum::options(),
                'gender'             => GenderEnum::options(),
                'marital_status'     => MaritalStatusEnum::options(),
                'severity'           => SeverityEnum::options(),
                'session_category'   => SessionCategoryEnum::options(),
                'treatment_status'   => TreatmentStatusEnum::options(),
                'treatment_phase'    => TreatmentPhaseEnum::options(),
                'payment_method'     => PaymentMethodEnum::options(),
                'commission_type'    => CommissionTypeEnum::options(),
                'common_status'      => CommonStatusEnum::options(),
            ],

            // Contexto de Compañía
            'current_company' => $context['current_company'],
            'current_company_id' => $context['current_company'] ? $context['current_company']['id'] : null,

            // Contexto de Sucursal
            'current_branch' => $context['current_branch'],
            'current_branch_id' => $context['current_branch'] ? $context['current_branch']['id'] : null,

            // Listados para Switchers
            'all_companies' => $context['all_companies'],
            'available_branches' => $context['available_branches'],

            // Mensajes Flash (Genérico)
            'flash' => array_filter([
                'success' => $request->session()->get('success'),
                'error' => $request->session()->get('error'),
                'message' => $request->session()->get('message'),
                'type' => $request->session()->get('type'),
                'patient' => $request->session()->get('patient'),
                'patient_id' => $request->session()->get('patient_id'),
            ]),

            //Datos generales de la app
            'appVersion' => config('app.version'),
            'appName' => config('app.name'),
            'env' => config('app.env'),
            'projectPath' => str_replace('\\', '/', base_path()),
            'currentRouteName' => Route::currentRouteName(),
            'dev_users' => config('app.env') === 'local' 
                ? (function() use ($request) {
                    $users = \App\Models\User::with('roles')->orderBy('id')->take(50)->get();
                    $currentUser = $request->user();
                    
                    if ($currentUser && !$users->contains('id', $currentUser->id)) {
                        // Recargar roles por seguridad y añadir a la colección
                        $currentUser->load('roles');
                        $users->push($currentUser);
                    }
                    
                    return $users->sortBy('id')->map(function($u) {
                        return [
                            'id' => $u->id,
                            'name' => $u->name,
                            'email' => $u->email,
                            'roles' => $u->getRoleNames(),
                        ];
                    })->values();
                })()
                : [],
            'gitInfo' => config('app.env') === 'local' ? Cache::remember('git_info', 300, function () {
                try {
                    $branch = trim(exec('git rev-parse --abbrev-ref HEAD'));
                    $hash = trim(exec('git log -1 --format=%h'));
                    return "git: $branch @ $hash";
                } catch (\Throwable $e) {
                    return null;
                }
            }) : null,
            'techInfo' => config('app.env') === 'local' ? [
                'php' => phpversion(),
                'laravel' => app()->version(),
                'db' => DB::connection()->getDriverName() . ' ' . DB::connection()->getPdo()->getAttribute(\PDO::ATTR_SERVER_VERSION)
            ] : null,
            'queryDebug' => config('app.env') === 'local' ? [
                'count' => count(DB::getQueryLog()),
                'time'  => collect(DB::getQueryLog())->sum('time')
            ] : null,
            'memoryUsage' => config('app.env') === 'local' ? round(memory_get_peak_usage(true) / 1024 / 1024, 2) : null,
            'totalTime' => config('app.env') === 'local' ? round((microtime(true) - LARAVEL_START) * 1000) : null,
            'pendingJobsCount' => config('app.env') === 'local' ? DB::table('jobs')->count() : 0,
        ];
    }

    private function getAuthContext(Request $request): array
    {
        $user = $request->user();
        $currentCompany = null;
        $contextCompanyId = null;
        $allCompanies = [];
        $activeBranch = null;
        $availableBranches = collect();

        // 1. Guardia Patient (Sin cambios)
        if (Auth::guard('patient')->check()) {
            $patient = Auth::guard('patient')->user();
            return [
                'auth' => [
                    'user' => $patient?->only('id', 'name', 'email', 'rut', 'company_id'),
                    'guard' => 'patient',
                    'roles' => [],
                    'permissions' => [],
                ],
                'current_company' => null,
                'current_branch' => null,
                'available_branches' => [],
                'all_companies' => [],
            ];
        }

        if ($user) {
            // --- 2. DETERMINAR ID DE EMPRESA (Lógica simplificada y segura) ---

            // Prioridad 1: Lo que el Superadmin eligió en el Switcher (Sesión)
            $contextCompanyId = $request->session()->get('current_company_id');

            // --- 2. DETERMINAR ID DE EMPRESA (Con auto-reparación) ---
            $contextCompanyId = $request->session()->get('current_company_id');

            if (!$contextCompanyId) {
                // Intentamos recuperar del perfil del usuario
                if ($user->company_id) {
                    $contextCompanyId = $user->company_id;
                }
                // Si es Superadmin y no tiene empresa asignada, tomamos la primera
                elseif ($user->isSuperAdmin()) {
                    $firstCompany = Company::first();
                    $contextCompanyId = $firstCompany ? $firstCompany->id : null;
                }

                // 🎯 CRUCIAL: Si encontramos un ID, lo guardamos en la sesión 
                // para que en la siguiente petición no sea null.
                if ($contextCompanyId) {
                    $request->session()->put('current_company_id', $contextCompanyId);
                }
            }

            // Prioridad 3: Si sigue siendo null (Superadmin recién logueado), tomamos la primera
            if (!$contextCompanyId && $user->isSuperAdmin()) {
                $firstCompany = Company::first();
                $contextCompanyId = $firstCompany ? $firstCompany->id : null;
            }

            // --- 3. CARGAR OBJETO COMPAÑÍA ---
            if ($contextCompanyId) {
                // Usamos withoutGlobalScopes() por pura seguridad, aunque ya quitamos el trait
                $currentCompany = Company::withoutGlobalScopes()
                    ->with(['logo', 'dteConfiguration'])
                    ->select(['id', 'business_name', 'rut', 'giro', 'email', 'phone', 'business_type'])
                    ->find($contextCompanyId);
            }

            // --- 4. DETERMINAR SUCURSALES DISPONIBLES ---
            if ($user->isSuperAdmin()) {
                $allCompanies = Company::withoutGlobalScopes()
                    ->with('logo')
                    ->select(['id', 'business_name', 'rut'])
                    ->get();
                if ($contextCompanyId) {
                    $availableBranches = Branch::where('company_id', $contextCompanyId)
                        ->select('id', 'name', 'allows_onsite', 'allows_home')->get();
                }
            } else {
                // Usuarios normales: Solo sus sucursales en ESA empresa
                $availableBranches = $user->branches()
                    ->where('branches.company_id', $contextCompanyId)
                    ->select('branches.id', 'branches.name', 'branches.allows_onsite', 'branches.allows_home')->get();
                }
            // --- 5. DETERMINAR SUCURSAL ACTIVA (Solo lectura) ---
            $activeBranchId = $request->session()->get('active_branch_id');

            if (!$activeBranchId && $availableBranches->isNotEmpty()) {
                // Intentar buscar la principal asignada al usuario
                $mainBranch = $user->branches()
                    ->where('branches.company_id', $contextCompanyId)
                    ->wherePivot('is_main', true)
                    ->first();

                $activeBranchId = $mainBranch ? $mainBranch->id : $availableBranches->first()->id;
            }

            if ($activeBranchId && $availableBranches->isNotEmpty()) {
                $activeBranch = $availableBranches->firstWhere('id', $activeBranchId);
            }
        }

        $doctorBranch = null;
        if ($user && $user->hasRole('kine') && $user->doctor) {
            $doctorBranch = $user->doctor->getBranchAttribute();
        }

        return [
            'auth' => [
                'user' => $user?->only('id', 'name', 'email'),
                'guard' => 'web',
                'roles' => fn() => $user?->getRoleNames() ?? [],
                'permissions' => fn() => $user?->getAllPermissions()->pluck('name') ?? [],
                'doctor_branch' => $doctorBranch,
            ],
            'current_company' => $currentCompany ? $currentCompany->toArray() : null,
            'all_companies' => $allCompanies,
            'current_branch' => $activeBranch ? (is_array($activeBranch) ? $activeBranch : $activeBranch->toArray()) : null,
            'available_branches' => $availableBranches,
        ];
    }
}
