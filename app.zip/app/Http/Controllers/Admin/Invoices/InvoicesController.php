<?php

namespace App\Http\Controllers\Admin\Invoices;

use App\Http\Controllers\Controller;
use App\Http\Requests\InvoiceIssueRequest;
use App\Models\Invoice;
use App\Models\TreatmentSession;
use App\Models\PatientPlan;
use App\Services\Invoices\InvoiceService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendInvoiceMail;

class InvoicesController extends Controller
{
  public function index(Request $req)
  {
    $this->authorize('viewAny', Invoice::class);
    $q = Invoice::with('patient')->get();

    if ($req->filled('status'))    $q->where('status', $req->status);
    if ($req->filled('sii_status')) $q->where('sii_status', $req->sii_status);



    return inertia('Invoices/Index', [
      'invoices' => $q,
      'filters'  => $req->only(['status', 'sii_status']),
    ]);
  }

  /* public function issueForSession(InvoiceIssueRequest $req, InvoiceService $svc, TreatmentSession $session)
  {
    $this->authorize('update', $session);
    $invoice = $svc->issueForSession($session, $req->input('type', 'boleta'));

    return back()->with('ok', "Documento emitido (#{$invoice->document_number})");
  }

  public function issueForPlan(InvoiceIssueRequest $req, InvoiceService $svc, PatientPlan $patientPlan)
  {
    $this->authorize('update', $patientPlan);
    $invoice = $svc->issueForPlan($patientPlan, $req->input('type', 'factura'));

    return back()->with('ok', "Documento emitido (#{$invoice->document_number})");
  } */

  public function cancel(Request $req, InvoiceService $svc, Invoice $invoice)
  {
    $this->authorize('update', $invoice);
    $svc->cancelWithCreditNote($invoice, $req->input('reason', 'Anulación por solicitud'));
    return back()->with('ok', 'Documento anulado.');
  }

  public function show(Invoice $invoice)
  {
    $this->authorize('view', $invoice);
    $invoice->load(['patient', 'items.sellable', 'treatmentSession']);
    return inertia('Invoices/Show', ['invoice' => $invoice]);
  }

  public function downloadPdf(Invoice $invoice)
  {
    $this->authorize('view', $invoice); // Usamos view por ahora para asegurar acceso
    abort_unless($invoice->pdf_path && Storage::disk('private')->exists($invoice->pdf_path), 404);

    return Storage::disk('private')->download($invoice->pdf_path);
  }

  public function sendEmail(Invoice $invoice)
  {
    $this->authorize('sendEmail', $invoice);
    $patient = $invoice->patient;

    if (!$patient->email) {
      return response()->json(['message' => 'El receptor no tiene un correo electrónico registrado.'], 422);
    }

    try {
      Mail::to($patient->email)->send(new SendInvoiceMail($invoice));
      return response()->json(['message' => "Correo enviado exitosamente a {$patient->email}"]);
    } catch (\Exception $e) {
      return response()->json(['message' => 'Error al enviar el correo: ' . $e->getMessage()], 500);
    }
  }
}
