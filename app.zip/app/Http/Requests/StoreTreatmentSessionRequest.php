<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreTreatmentSessionRequest extends FormRequest
{
  /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true; // Ajustar según permisos necesarios
    }

    /**
     * Get the custom attributes for validator errors.
     */
    public function attributes(): array
    {
        return [
            'techniques' => 'técnicas',
            'exercises' => 'ejercicios',
        ];
    }

    /**
     * Prepare the data for validation.
     */
    protected function prepareForValidation(): void
    {
        $activeBranchId = session('active_branch_id');
        $companyId = session('current_company_id');


        // 1. Usar merge() para agregar 'company_id' si no existe en la solicitud
        // La lógica $validated['company_id'] = $currentCompanyId; se traduce a:
        
        if (!$this->has('company_id') && $companyId) {
            $this->merge([
                'company_id' => $companyId,
            ]);
        }

        // 2. Usar merge() para agregar 'branch_id' si no existe en la solicitud
        // La lógica $validated['branch_id'] = $activeBranchId; se traduce a:
        
        if (!$this->has('branch_id') && $activeBranchId) {
            $this->merge([
                'branch_id' => $activeBranchId,
            ]);
        }

        // Valores por defecto
        if (!$this->has('status')) {
            $this->merge(['status' => 'scheduled']);
        }

        if (!$this->has('duration')) {
            $this->merge(['duration' => 45]);
        }

        // Para sesiones completadas, asegurar que tengan evaluación de dolor
        if ($this->has('status') && $this->status === 'completed') {
            $this->validate([
                'pain_before' => 'required|integer|min:0|max:10',
                'pain_after' => 'required|integer|min:0|max:10',
            ]);
        }

        // Asegurar que los arrays están correctamente configurados
        // Los arrays deben llegar como arrays desde el frontend, no convertirlos a JSON aquí
        // Laravel automáticamente manejará la conversión a JSON en el modelo gracias al $casts
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\Rule|array|string>
     */
    public function rules(): array
    {
        return [
            'company_id' => 'nullable|exists:branches,id',
            'branch_id' => 'nullable|exists:branches,id',
            'treatment_id' => 'nullable|exists:treatments,id',
            'doctor_id' => 'required|exists:doctors,id',
            'patient_id' => 'required|exists:patients,id',
            'item_id' => 'nullable|exists:items,id',
            'room_id' => 'nullable|exists:rooms,id',
            'base_price_clp' => 'nullable|integer|min:0',
            'patient_plan_id' => 'nullable|exists:patient_plans,id',
            'confirm_defaults' => 'nullable|boolean', // Nuevo flag para confirmar valores por defecto
            'date' => 'required|date',
            'time' => 'required|date_format:H:i',
            'duration' => 'required|integer|min:15|max:180',
            'status' => 'required|in:scheduled,in_progress,completed,cancelled,not_show,confirmed',
            
            // --- CAMPOS DE TRATAMIENTO (Para creación automática) ---
            'diagnostic_code' => 'required_without:treatment_id|nullable|exists:diagnostics,code',
            'referral_doctor_name' => 'nullable|string',
            'referral_diagnosis' => 'nullable|string',
            'total_sessions' => 'nullable|integer',
            'initial_pain_level' => 'nullable|integer',
            'initial_pain_map' => 'nullable|array',
            'body_part' => 'nullable|string',
            'laterality' => 'nullable|string',

            // --- NUEVOS CAMPOS SOAP ---
            'subjective' => 'nullable|string',
            'objective' => 'nullable|string',
            'assessment' => 'nullable|string',
            'plan' => 'nullable|string',
            
            'pain_level' => 'nullable|integer|min:0|max:10',
            'session_pain_map' => 'nullable|array',
            'evaluation_data' => 'nullable|array',
            'activities_data' => 'nullable|array',
            'attachments' => 'nullable|array',
            
            'consumes_plan' => 'nullable|boolean',
            'cost_breakdown' => 'nullable|array',
            'meta' => 'nullable|array',

            // Evaluación del dolor (Legacy / Específicos)
            'pain_before' => 'nullable|integer|min:0|max:10',
            'pain_after' => 'nullable|integer|min:0|max:10',
            // ROM (Rango de Movimiento)
            'rom_flexion_before' => 'nullable|integer|min:0|max:180',
            'rom_flexion_after' => 'nullable|integer|min:0|max:180',
            'rom_abduction_before' => 'nullable|integer|min:0|max:180',
            'rom_abduction_after' => 'nullable|integer|min:0|max:180',
            'rom_rotation_before' => 'nullable|integer|min:0|max:180',
            'rom_rotation_after' => 'nullable|integer|min:0|max:180',
            // Arrays JSON
            'techniques' => 'nullable|array',
            'exercises' => 'nullable|array',
            // Notas
            'notes' => 'nullable|string',
            'homework' => 'nullable|string',
            'next_goals' => 'nullable|string',
            'cancellation_note' => 'nullable|string',
        ];
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'treatment_id.required' => 'El tratamiento es obligatorio',
            'treatment_id.exists' => 'El tratamiento seleccionado no existe',
            'doctor_id.required' => 'El kinesiólogo es obligatorio',
            'doctor_id.exists' => 'El kinesiólogo seleccionado no existe',
            'patient_id.required' => 'El paciente es obligatorio',
            'patient_id.exists' => 'El paciente seleccionado no existe',

            'month_session_number.integer' => 'El número de sesión del mes debe ser un número entero',
            'month_session_number.min' => 'El número de sesión del mes debe ser al menos 1',
            'date.required' => 'La fecha es obligatoria',
            'date.date' => 'La fecha debe tener un formato válido',
            'time.required' => 'La hora es obligatoria',
            'time.date_format' => 'La hora debe tener el formato HH:MM',
            'duration.required' => 'La duración es obligatoria',
            'duration.integer' => 'La duración debe ser un número entero',
            'duration.min' => 'La duración debe ser al menos 15 minutos',
            'duration.max' => 'La duración no puede exceder 180 minutos',
            'status.required' => 'El estado es obligatorio',
            'status.in' => 'El estado debe ser Programada, Completada,En Progreso, Cancelada o No Asistió',
            'pain_before.integer' => 'El dolor inicial debe ser un número entero',
            'pain_before.min' => 'El dolor inicial debe ser al menos 0',
            'pain_before.max' => 'El dolor inicial no puede exceder 10',
            'pain_after.integer' => 'El dolor final debe ser un número entero',
            'pain_after.min' => 'El dolor final debe ser al menos 0',
            'pain_after.max' => 'El dolor final no puede exceder 10',
            'rom_flexion.integer' => 'La flexión debe ser un número entero',
            'rom_flexion.min' => 'La flexión debe ser al menos 0 grados',
            'rom_flexion.max' => 'La flexión no puede exceder 180 grados',
            'rom_abduction.integer' => 'La abducción debe ser un número entero',
            'rom_abduction.min' => 'La abducción debe ser al menos 0 grados',
            'rom_abduction.max' => 'La abducción no puede exceder 180 grados',
            'rom_rotation.integer' => 'La rotación debe ser un número entero',
            'rom_rotation.min' => 'La rotación debe ser al menos 0 grados',
            'rom_rotation.max' => 'La rotación no puede exceder 180 grados',
            'techniques.array' => 'Las técnicas deben ser una lista válida',
            'exercises.array' => 'Los ejercicios deben ser una lista válida',
        ];
    }

    

}
